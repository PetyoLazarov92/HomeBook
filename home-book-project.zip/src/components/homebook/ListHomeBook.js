import React, { Component } from 'react';
import CoOwnership from '../coownerships/CoOwnership';
import observer from '../../infrastructure/observer';
import homeBookService from '../../services/homeBookService'

export default class ListHomeBook extends Component{
    constructor(props) {
        super(props);

        this.state = {
            hombook : []
        }
    }

    getHomeBook = (id) => {
        homeBookService.loadPostById(id)
            .then(res => {
                console.log(res);
                this.setState({
                    coOwnerships: res
                })
            })
            .catch(res =>  observer.trigger(observer.events.notification, {type: 'error', message: res.responseJSON.description }));
    }

    componentDidMount = () => {
        const { match: { params } } = this.props;
        console.log(params.id);
        
        this.getHomeBook(params.id);
    }

    render = () => {        
        return (
            <div>
                <h1>Home Book</h1>
                <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Names</th>
                        <th>Starting Date</th>
                        <th>Type Of Buisnes</th>
                        <th>Type Of Occupant</th>
                        <th>Controls</th>
                      </tr>
                    </thead>
                    <tbody>
                        {/* {this.state.coOwnerships.map((p, i) => <CoOwnership key={p._id} index={i} {...p} />)} */}
                    </tbody>
                </table>
            </div>
        )
    }
}